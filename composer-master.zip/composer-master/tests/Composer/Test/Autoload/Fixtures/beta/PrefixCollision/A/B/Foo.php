<?php

class PrefixCollision_A_B_Foo
{
    public static $loaded = true;
}
