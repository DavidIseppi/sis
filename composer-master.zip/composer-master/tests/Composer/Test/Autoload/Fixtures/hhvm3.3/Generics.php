<?hh

class GenericsClass<Tk, Tv> {
}
