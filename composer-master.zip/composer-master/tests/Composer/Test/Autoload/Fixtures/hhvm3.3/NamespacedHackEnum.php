<?hh

namespace Foo;

enum BarEnum: string {
  HERP = 'DERP';
}
